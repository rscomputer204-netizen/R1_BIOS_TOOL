import urllib.request
import json
import re

url_topic16 = "https://winraid.level1techs.com/t/intel-converged-security-management-engine-drivers-firmware-and-tools-16/89959.json"
req = urllib.request.Request(url_topic16, headers={"User-Agent": "Mozilla/5.0"})

with urllib.request.urlopen(req, timeout=15) as resp:
    data = json.loads(resp.read().decode("utf-8"))

stream = data.get("post_stream", {}).get("stream", [])
print(f"Total post IDs in 89959: {len(stream)}")

# Check last 50 posts
recent_ids = stream[-50:]
params = "&".join([f"post_ids[]={pid}" for pid in recent_ids])
chunk_url = f"https://winraid.level1techs.com/t/89959/posts.json?{params}"

req2 = urllib.request.Request(chunk_url, headers={"User-Agent": "Mozilla/5.0"})
with urllib.request.urlopen(req2, timeout=20) as r:
    cdata = json.loads(r.read().decode("utf-8"))

posts = cdata.get("post_stream", {}).get("posts", [])
print(f"Retrieved {len(posts)} posts from 89959.")

for p in posts:
    num = p.get("post_number")
    user = p.get("username")
    cooked = p.get("cooked", "")
    text = re.sub(r'<[^>]+>', ' ', cooked)
    
    # check for CSME 17, 18, 19, Meteor Lake, Arrow Lake, Lunar Lake, download links
    if any(k in text for k in ["17.", "18.", "19.", "Meteor", "Arrow", "Lunar", "mega.nz", "drive.google"]):
        links = re.findall(r'href=["\']([^"\']+)["\']', cooked)
        val_links = [l for l in links if any(x in l for x in ["mega", "drive", "mediafire", "uploads", "firmware"])]
        print(f"\n--- Post #{num} by {user} ---")
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        for l in lines[:5]:
            print("  ", l[:120])
        if val_links:
            print("   Links:", val_links[:3])
