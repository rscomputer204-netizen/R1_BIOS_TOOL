import os, glob

repo = r"Firmware_Repository/ME_Region"
majors = sorted(
    [d for d in os.listdir(repo) if os.path.isdir(os.path.join(repo, d))],
    key=lambda x: int(x) if x.isdigit() else 999
)

print(f"ME Region Major Versions present: {majors}")
total_me_files = 0
version_summary = []

for m in majors:
    mdir = os.path.join(repo, m)
    files = []
    for root, _, fnames in os.walk(mdir):
        for f in fnames:
            if f.endswith(".bin") or f.endswith(".rgn") or f.endswith(".rom"):
                files.append(f)
    files.sort()
    total_me_files += len(files)
    first_f = files[0] if files else "N/A"
    last_f = files[-1] if files else "N/A"
    print(f"Major {m:>2}: {len(files):>4} files | First: {first_f} | Latest: {last_f}")
    version_summary.append({
        "major": m,
        "count": len(files),
        "first": first_f,
        "latest": last_f
    })

print(f"\nTotal ME Region Donor files: {total_me_files}")

# Check PMC, PCHC, PHY
for sub in ["PMC_Region", "PCHC_Region", "PHY_Region"]:
    sdir = os.path.join("Firmware_Repository", sub)
    sfiles = []
    if os.path.exists(sdir):
        for root, _, fnames in os.walk(sdir):
            for f in fnames:
                if f.endswith(".bin") or f.endswith(".rgn"):
                    sfiles.append(f)
    sfiles.sort()
    first_f = sfiles[0] if sfiles else "N/A"
    last_f = sfiles[-1] if sfiles else "N/A"
    print(f"{sub}: {len(sfiles)} files | First: {first_f} | Latest: {last_f}")
