import os
import sys
import json
import re
import urllib.request
import urllib.parse
import shutil
import zipfile
import subprocess

TARGET_DIR = r"d:\BIOS_-TOOL\Downloaded_Donors_WinRaid"
ATTACHMENTS_DIR = os.path.join(TARGET_DIR, "forum_attachments")
EXTRACTED_DIR = os.path.join(TARGET_DIR, "extracted_binaries")
os.makedirs(ATTACHMENTS_DIR, exist_ok=True)
os.makedirs(EXTRACTED_DIR, exist_ok=True)

TOPIC_URL = "https://winraid.level1techs.com/t/intel-cs-me-cs-txe-cs-sps-gsc-pmc-pchc-phy-orom-firmware-repositories/30869.json"
BASE_URL = "https://winraid.level1techs.com"

print("1. Fetching full topic stream from Win-RAID...")
req = urllib.request.Request(TOPIC_URL, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
with urllib.request.urlopen(req, timeout=15) as resp:
    topic_data = json.loads(resp.read().decode("utf-8"))

stream = topic_data.get("post_stream", {}).get("stream", [])
print(f"Total post IDs found: {len(stream)}")

# Fetch all posts in chunks of 30
all_posts = []
chunk_size = 30
for i in range(0, len(stream), chunk_size):
    batch = stream[i:i+chunk_size]
    params = "&".join([f"post_ids[]={pid}" for pid in batch])
    chunk_url = f"https://winraid.level1techs.com/t/30869/posts.json?{params}"
    try:
        r_batch = urllib.request.Request(chunk_url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        with urllib.request.urlopen(r_batch, timeout=20) as r:
            cdata = json.loads(r.read().decode("utf-8"))
            all_posts.extend(cdata.get("post_stream", {}).get("posts", []))
    except Exception as e:
        print(f"Error fetching chunk {i}: {e}")

print(f"Total posts retrieved: {len(all_posts)}")

# 2. Extract direct attachments and external links
forum_attachments = []
external_links = []

for p in all_posts:
    post_num = p.get("post_number")
    username = p.get("username")
    created_at = p.get("created_at")
    cooked = p.get("cooked", "")
    
    # Direct uploads: /uploads/short-url/xxxx.ext or /uploads/default/...
    # Match <a href="...url..." ...>filename</a>
    matches = re.findall(r'<a\s+[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', cooked, re.DOTALL)
    for href, text in matches:
        clean_text = re.sub(r'<[^>]+>', '', text).strip()
        full_url = href
        if full_url.startswith("/"):
            full_url = BASE_URL + full_url
            
        # Check if direct attachment
        is_archive = any(full_url.lower().endswith(ext) for ext in [".rar", ".zip", ".7z", ".bin", ".tar", ".gz"])
        is_short_url = "/uploads/short-url/" in full_url
        
        if is_archive or is_short_url:
            forum_attachments.append({
                "post": post_num,
                "user": username,
                "date": created_at,
                "url": full_url,
                "filename": clean_text
            })
        elif any(cloud in full_url.lower() for cloud in ["mega.nz", "drive.google.com", "mediafire.com"]):
            external_links.append({
                "post": post_num,
                "user": username,
                "url": full_url,
                "label": clean_text
            })

print(f"\nFound {len(forum_attachments)} direct forum attachments.")
print(f"Found {len(external_links)} cloud repository links.")

# 3. Download all direct attachments
downloaded_files = []
for idx, att in enumerate(forum_attachments, 1):
    url = att["url"]
    label = att["filename"]
    # Clean label to a safe filename
    safe_name = re.sub(r'[\\/*?:"<>|]', '_', label)
    safe_name = re.sub(r'\s*\(\d+(\.\d+)?\s*[KMG]?B\)\s*$', '', safe_name) # remove size suffix like (1.7 MB)
    if not any(safe_name.lower().endswith(ext) for ext in [".rar", ".zip", ".7z", ".bin"]):
        # guess extension from url
        if ".rar" in url.lower(): safe_name += ".rar"
        elif ".zip" in url.lower(): safe_name += ".zip"
        elif ".7z" in url.lower(): safe_name += ".7z"
        elif ".bin" in url.lower(): safe_name += ".bin"
        else: safe_name += ".bin"
        
    dest_path = os.path.join(ATTACHMENTS_DIR, f"post_{att['post']}_{safe_name}")
    print(f"[{idx}/{len(forum_attachments)}] Downloading Post #{att['post']} by {att['user']}: {safe_name}...")
    
    if os.path.exists(dest_path) and os.path.getsize(dest_path) > 0:
        print(f"   -> Already exists ({os.path.getsize(dest_path)} bytes)")
        downloaded_files.append((dest_path, att))
        continue
        
    try:
        dl_req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        with urllib.request.urlopen(dl_req, timeout=30) as dl_resp:
            content = dl_resp.read()
            with open(dest_path, "wb") as f_out:
                f_out.write(content)
        print(f"   -> Downloaded ({len(content)} bytes)")
        downloaded_files.append((dest_path, att))
    except Exception as e:
        print(f"   -> Download failed: {e}")

# 4. Extract archives into extracted_binaries
print("\n4. Extracting archives...")
extracted_binaries = []
for fpath, meta in downloaded_files:
    fname = os.path.basename(fpath)
    if fname.lower().endswith(".zip"):
        try:
            with zipfile.ZipFile(fpath, 'r') as zf:
                for member in zf.namelist():
                    if any(member.lower().endswith(ext) for ext in [".bin", ".rgn", ".rom"]):
                        target_out = os.path.join(EXTRACTED_DIR, os.path.basename(member))
                        with zf.open(member) as s, open(target_out, "wb") as d:
                            d.write(s.read())
                        extracted_binaries.append(target_out)
                        print(f"   Extracted (ZIP): {os.path.basename(member)}")
        except Exception as e:
            print(f"   Zip extraction error on {fname}: {e}")
    elif fname.lower().endswith((".rar", ".7z")):
        # Use bsdtar
        try:
            sub = subprocess.run(["tar", "-xf", fpath, "-C", EXTRACTED_DIR], capture_output=True, text=True)
            if sub.returncode == 0:
                print(f"   Extracted (TAR): {fname}")
            else:
                print(f"   Tar failed for {fname}: {sub.stderr.strip()}")
        except Exception as e:
            print(f"   Archive extraction error: {e}")
    elif fname.lower().endswith(".bin"):
        dest_bin = os.path.join(EXTRACTED_DIR, fname)
        shutil.copy2(fpath, dest_bin)
        extracted_binaries.append(dest_bin)

# List all extracted bins
all_bins = [os.path.join(EXTRACTED_DIR, f) for f in os.listdir(EXTRACTED_DIR) if os.path.isfile(os.path.join(EXTRACTED_DIR, f))]
print(f"\nTotal extracted binary files in {EXTRACTED_DIR}: {len(all_bins)}")

# 5. Save summary report
summary = {
    "total_attachments_downloaded": len(downloaded_files),
    "total_binaries_extracted": len(all_bins),
    "extracted_files": [os.path.basename(b) for b in all_bins],
    "master_external_repositories": external_links
}

with open(os.path.join(TARGET_DIR, "winraid_harvest_report.json"), "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=4)

print("\nSummary saved to winraid_harvest_report.json!")
