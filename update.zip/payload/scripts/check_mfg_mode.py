with open(r"C:\Users\R1 LAB\Desktop\MUNNA VI\Latitude 5450 LA-M366P Rev 1.0.BIN", "rb") as f:
    d = f.read()

import re

for s in [
    b"Manufacturing Mode", b"Service Tag", b"Not Programmed", b"Set Service Tag",
    b"Tag:", b"ServiceTag", b"SVCTAG", b"SVC_TAG", b"DMI", b"Asset"
]:
    m_asc = list(re.finditer(re.escape(s), d, re.IGNORECASE))
    s_u16 = s.decode('latin1').encode('utf-16le')
    m_u16 = list(re.finditer(re.escape(s_u16), d))
    if m_asc or m_u16:
        print(f"'{s.decode()}': ASCII={len(m_asc)}, UTF-16={len(m_u16)}")
