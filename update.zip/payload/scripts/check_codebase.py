with open(r"C:\Users\R1 LAB\Desktop\MUNNA VI\Latitude 5450 LA-M366P Rev 1.0.BIN", "rb") as f:
    d = f.read()

import re

for sig in [
    b"American Megatrends", b"Aptio", b"$AMIEFI$", b"NVAR",
    b"Insyde", b"H2O", b"FDM$", b"$_IFLUSH_",
    b"Phoenix", b"SecureCore",
    b"Dell Client", b"Dell System", b"Dell Inc", b"Dell Computer"
]:
    matches = [m.start() for m in re.finditer(re.escape(sig), d, re.IGNORECASE)]
    if matches:
        print(f"{sig.decode(errors='ignore')}: found at {len(matches)} places, first at {hex(matches[0])}")
