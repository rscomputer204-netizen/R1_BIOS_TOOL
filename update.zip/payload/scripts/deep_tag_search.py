import os, re, string

with open(r"C:\Users\R1 LAB\Desktop\MUNNA VI\Latitude 5450 LA-M366P Rev 1.0.BIN", "rb") as f:
    d = f.read()

print("Searching entire 32MB file for Service Tag patterns...")

# 1. Search for regex near known Dell patterns
# In Dell BIOS, Service Tag is 7 chars, e.g. 1234567, ABC1234, 1AB2C3D, etc.
# Check ASCII:
# Dell Service tag is usually 7 characters uppercase alphanumeric: [A-Z0-9]{7}
# Let's search for any occurrence of 'ST' or 'SV' or 'Tag' or 'Service' or 'Asset'
dell_tag_pats = [
    rb"(?i)service[_\s\-]?tag[^\w\r\n]{0,8}([A-Z0-9]{7})\b",
    rb"(?i)asset[_\s\-]?tag[^\w\r\n]{0,8}([A-Z0-9]{7})\b",
    rb"(?i)serial[_\s\-]?number[^\w\r\n]{0,8}([A-Z0-9]{7})\b",
    rb"(?i)\bST[:=\s]{1,4}([A-Z0-9]{7})\b",
]

found_tags = []
for pat in dell_tag_pats:
    for m in re.finditer(pat, d):
        tag = m.group(1).decode('latin1')
        print(f"Matched pattern {pat} -> '{tag}' at {hex(m.start())}")
        found_tags.append((tag, m.start()))

# Also search UTF-16LE for the same patterns
for kw in [b"Service Tag", b"Asset Tag", b"Serial Number"]:
    kw_u16 = kw.decode('latin1').encode('utf-16le')
    idx = 0
    while True:
        idx = d.find(kw_u16, idx)
        if idx == -1: break
        ctx = d[idx : idx + 100]
        try:
            txt = ctx.decode('utf-16le', errors='ignore')
            print(f"UTF-16 keyword '{kw.decode()}' at {hex(idx)}: {repr(txt[:40])}")
        except Exception:
            pass
        idx += 2

if not found_tags:
    print("No regex matches found near keywords.")
