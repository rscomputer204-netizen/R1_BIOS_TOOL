import os, struct, re

with open(r"C:\Users\R1 LAB\Desktop\MUNNA VI\Latitude 5450 LA-M366P Rev 1.0.BIN", "rb") as f:
    d = f.read()

# SMBIOS structures have:
# Type (1 byte), Length (1 byte), Handle (2 bytes)
# Followed by formatted section
# Followed by unformatted section (strings separated by 0x00, ending with 0x00 0x00)
#
# Type 1: System Information
# Length is usually 0x1B or 0x20 or 0x2C
# Offset 0x04: Manufacturer string index
# Offset 0x05: Product Name string index
# Offset 0x06: Version string index
# Offset 0x07: Serial Number (Service Tag!) string index
# Offset 0x08: UUID (16 bytes)
#
# Type 2: Baseboard Information
# Type 3: System Enclosure or Chassis (Serial Number at offset 0x06)

print("Scanning for SMBIOS Type 1, 2, 3 structures...")
# Look for structures followed by strings containing 'Dell' or 'Latitude'
for m in re.finditer(b"Dell", d):
    off = m.start()
    # Check backwards for structure header
    # Up to 256 bytes back
    chunk = d[max(0, off - 256) : off + 256]
    # Let's inspect string block
    # Strings in SMBIOS are null-terminated
    # Let's see what null-terminated strings surround 'Dell'
    start_str = d.rfind(b"\x00\x00", 0, off)
    if start_str != -1 and off - start_str < 300:
        end_str = d.find(b"\x00\x00", off)
        if end_str != -1 and end_str - off < 300:
            str_block = d[start_str+2 : end_str].split(b"\x00")
            decoded = [s.decode('latin1', errors='ignore') for s in str_block if s]
            if len(decoded) >= 2:
                print(f"String table near {hex(off)}: {decoded}")
