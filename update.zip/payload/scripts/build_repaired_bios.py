import os
import sys
import shutil

sys.path.insert(0, r"d:\BIOS_-TOOL")
from R1_CSME_Analyzer.r1_csme_parser import R1CSMEAnalyzer

BASE_DUMP = r"C:\Users\R1 LAB\Desktop\MUNNA VI\New folder\Latitude 5450 LA-M366P Rev 1.0.BIN"
OFFICIAL_DIR = r"C:\Users\R1 LAB\Desktop\MUNNA VI\New folder\Extracted_Official\Firmware\3 Latitude_5450_Precision_3490_RPL_1.27.1 v1.27.1\Firmware"
OUTPUT_DIR = r"C:\Users\R1 LAB\Desktop\MUNNA VI\New folder\REPAIRED_BIOS"
os.makedirs(OUTPUT_DIR, exist_ok=True)

OFFICIAL_BIOS = os.path.join(OFFICIAL_DIR, "3 Latitude_5450_Precision_3490_RPL_1.27.1 v1.27.1 -- 1 System BIOS with BiosGuard v1.27.1.bin")
OFFICIAL_ME_CON = os.path.join(OFFICIAL_DIR, "3 Latitude_5450_Precision_3490_RPL_1.27.1 v1.27.1 -- 3 Intel Management Engine Consumer Firmware Update v16.1.42.2872.bin")
OFFICIAL_ME_COR = os.path.join(OFFICIAL_DIR, "3 Latitude_5450_Precision_3490_RPL_1.27.1 v1.27.1 -- 2 Intel Management Engine Corporate Firmware Update v16.1.42.2872.bin")

with open(BASE_DUMP, "rb") as f:
    dump_data = bytearray(f.read())

print(f"Base dump size: {len(dump_data)} bytes (32 MB)")

# 1. Build FULL REPAIRED OFFICIAL 1.27.1 BIOS
# Replace BIOS Region at offset 0x800000 (length 24 MB = 25,165,824 bytes)
with open(OFFICIAL_BIOS, "rb") as f:
    official_bios_data = f.read()

assert len(official_bios_data) == 0x1800000, f"BIOS size mismatch: {len(official_bios_data)}"

repaired_full = bytearray(dump_data)
repaired_full[0x800000:0x2000000] = official_bios_data

out_full_path = os.path.join(OUTPUT_DIR, "Latitude_5450_LA-M366P_REPAIRED_FULL_v1.27.1.BIN")
with open(out_full_path, "wb") as f:
    f.write(repaired_full)

print(f"1. Generated Full 1.27.1 BIOS: {out_full_path} ({len(repaired_full)} bytes)")

# Verify with R1CSMEAnalyzer
a = R1CSMEAnalyzer(out_full_path)
info = a.parse()
print(f"   Verification: CSME {info.get('version')}, SKU: {info.get('sku')}, State: {info.get('fs_state')}")

# Also verify BIOS region header & reset vector
with open(out_full_path, "rb") as f:
    f.seek(0x800000)
    bios_head = f.read(16)
    f.seek(len(repaired_full) - 16)
    bios_tail = f.read(16)
print(f"   BIOS Region start: {bios_head.hex()}")
print(f"   Reset vector:      {bios_tail.hex()}")
