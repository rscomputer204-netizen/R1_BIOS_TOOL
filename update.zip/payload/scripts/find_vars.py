import os, struct, re

with open(r"C:\Users\R1 LAB\Desktop\MUNNA VI\Latitude 5450 LA-M366P Rev 1.0.BIN", "rb") as f:
    d = f.read()

# Let's search for typical UEFI variable names (UTF-16LE):
# e.g. Setup, BootOrder, PlatformLang, ConIn, ConOut, DellSetup, DellSystemId, ServiceTag, AssetTag
vars_to_search = [
    "ServiceTag", "Service_Tag", "AssetTag", "DellSystemId", "SystemId",
    "Setup", "BootOrder", "PlatformLang", "Dell", "Latitude"
]

print("Searching for UEFI variable names (UTF-16LE)...")
for v in vars_to_search:
    v_b = v.encode("utf-16le")
    matches = [m.start() for m in re.finditer(re.escape(v_b), d)]
    print(f"Var '{v}': found at {len(matches)} offsets: {[hex(x) for x in matches[:5]]}")
