with open(r"C:\Users\R1 LAB\Desktop\MUNNA VI\Latitude 5450 LA-M366P Rev 1.0.BIN", "rb") as f:
    d = f.read()

# Check each block of 64KB from 0x1800000 to 0x2000000
print("Analyzing 0x1800000 to 0x2000000:")
for addr in range(0x1800000, len(d), 0x10000):
    blk = d[addr : addr + 0x10000]
    ff_cnt = blk.count(b"\xFF")
    zero_cnt = blk.count(b"\x00")
    print(f"  {hex(addr)}: FF={ff_cnt/len(blk)*100:.1f}%, 00={zero_cnt/len(blk)*100:.1f}%, sig={blk[:16].hex()}")
