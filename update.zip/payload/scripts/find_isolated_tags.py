with open(r"C:\Users\R1 LAB\Desktop\MUNNA VI\Latitude 5450 LA-M366P Rev 1.0.BIN", "rb") as f:
    d = f.read()

import re

# Search for any standalone 7-character string surrounded by 0x00 or 0xFF:
# e.g. \x00[A-Z0-9]{7}\x00 or \xFF[A-Z0-9]{7}\xFF
# Dell service tags are 7 uppercase alphanumeric chars. Usually mix of letters and digits.
candidates = set()
for m in re.finditer(rb'[\x00\xFF]([A-Z0-9]{7})[\x00\xFF]', d):
    s = m.group(1).decode('latin1')
    # Filter out common false positives like '0000000', 'FFFFFFF', 'DEFAULT', 'PADDING'
    if len(set(s)) >= 3 and not s.startswith('DEFAULT') and not s.startswith('PADDING'):
        # Check if it has both letters and numbers, or at least looks like a tag
        candidates.add((s, hex(m.start())))

print(f"Total isolated 7-char alphanumeric strings found: {len(candidates)}")
for s, off in sorted(candidates, key=lambda x: int(x[1], 16))[:30]:
    print(f"  {off}: {s}")
