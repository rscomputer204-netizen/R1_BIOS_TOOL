import os
import sys

# Ensure d:\BIOS_-TOOL is in sys.path
sys.path.insert(0, r"d:\BIOS_-TOOL")
sys.path.insert(0, r"d:\BIOS_-TOOL\BIOSUtilities")

from BIOSUtilities.biosutilities.dell_pfs_extract import DellPfsExtract

exe_path = r"C:\Users\R1 LAB\Desktop\MUNNA VI\New folder\Latitude_5450_Precision_3490_1.27.1.exe"
out_dir = r"C:\Users\R1 LAB\Desktop\MUNNA VI\New folder\Extracted_Official"

os.makedirs(out_dir, exist_ok=True)

print(f"Extracting {exe_path} to {out_dir}...")
extractor = DellPfsExtract(input_object=exe_path, extract_path=out_dir)
res = extractor.parse_format()
print(f"Extraction result: {res}")
