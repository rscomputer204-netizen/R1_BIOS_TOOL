with open(r"C:\Users\R1 LAB\Desktop\MUNNA VI\Latitude 5450 LA-M366P Rev 1.0.BIN", "rb") as f:
    d = f.read()

import struct

idx = 0
fvs = []
while True:
    idx = d.find(b"_FVH", idx)
    if idx == -1: break
    fv_start = idx - 0x28
    if fv_start >= 0 and fv_start + 0x38 <= len(d):
        guid = d[fv_start : fv_start + 16]
        fv_len = struct.unpack("<Q", d[fv_start + 0x20 : fv_start + 0x28])[0]
        fvs.append((fv_start, fv_len, guid.hex()))
        print(f"FV at {hex(fv_start)}: length={hex(fv_len)}, GUID={guid.hex()}")
    idx += 4

print(f"Total FVs: {len(fvs)}")
