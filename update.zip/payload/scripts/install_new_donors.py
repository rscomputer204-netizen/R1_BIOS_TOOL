import os
import shutil
import json
import sys

sys.path.insert(0, r"d:\BIOS_-TOOL")
from R1_CSME_Analyzer.r1_csme_parser import R1CSMEAnalyzer

REPO_ROOT = r"d:\BIOS_-TOOL\Firmware_Repository\ME_Region"

# Sources:
SRC_16_CON = r"C:\Users\R1 LAB\Desktop\MUNNA VI\New folder\Extracted_Official\Firmware\3 Latitude_5450_Precision_3490_RPL_1.27.1 v1.27.1\Firmware\3 Latitude_5450_Precision_3490_RPL_1.27.1 v1.27.1 -- 3 Intel Management Engine Consumer Firmware Update v16.1.42.2872.bin"
SRC_16_COR = r"C:\Users\R1 LAB\Desktop\MUNNA VI\New folder\Extracted_Official\Firmware\3 Latitude_5450_Precision_3490_RPL_1.27.1 v1.27.1\Firmware\3 Latitude_5450_Precision_3490_RPL_1.27.1 v1.27.1 -- 2 Intel Management Engine Corporate Firmware Update v16.1.42.2872.bin"
SRC_18_CON = r"d:\BIOS_-TOOL\Downloaded_Donors_WinRaid\extracted_binaries\ME18.0.5.2098_Unconfigured.bin"
SRC_18_COR = r"C:\Users\R1 LAB\Desktop\MUNNA VI\New folder\Extracted_Official\Firmware\2 Latitude_5450_Precision_3490_MTL_1.27.1 v1.27.1\Firmware\2 Latitude_5450_Precision_3490_MTL_1.27.1 v1.27.1 -- 6 Intel Management Engine Corporate Firmware Update v18.0.21.2801.bin"

donors = [
    {
        "src": SRC_16_CON,
        "major": "16",
        "folder_name": "16.1.42.2872_CON_LP_A_PRD_EXTR_F2FD280C",
        "bin_name": "16.1.42.2872_CON_LP_A_PRD_EXTR_F2FD280C.bin",
        "sku": "CONSUMER",
        "power": "LP",
        "version": "16.1.42.2872",
        "minor": 1,
        "status": "PRODUCTION",
        "origin": "EXTRACTED"
    },
    {
        "src": SRC_16_COR,
        "major": "16",
        "folder_name": "16.1.42.2872_COR_LP_A_PRD_EXTR_FAD5E41F",
        "bin_name": "16.1.42.2872_COR_LP_A_PRD_EXTR_FAD5E41F.bin",
        "sku": "CORPORATE",
        "power": "LP",
        "version": "16.1.42.2872",
        "minor": 1,
        "status": "PRODUCTION",
        "origin": "EXTRACTED"
    },
    {
        "src": SRC_18_CON,
        "major": "18",
        "folder_name": "18.0.5.2098_CON_LP_A_PRD_EXTR_781EB3BA",
        "bin_name": "18.0.5.2098_CON_LP_A_PRD_EXTR_781EB3BA.bin",
        "sku": "CONSUMER",
        "power": "LP",
        "version": "18.0.5.2098",
        "minor": 0,
        "status": "PRODUCTION",
        "origin": "EXTRACTED"
    },
    {
        "src": SRC_18_COR,
        "major": "18",
        "folder_name": "18.0.21.2801_COR_LP_A_PRD_EXTR_E4E47E20",
        "bin_name": "18.0.21.2801_COR_LP_A_PRD_EXTR_E4E47E20.bin",
        "sku": "CORPORATE",
        "power": "LP",
        "version": "18.0.21.2801",
        "minor": 0,
        "status": "PRODUCTION",
        "origin": "EXTRACTED"
    }
]

installed = []
for d in donors:
    src_p = d["src"]
    if not os.path.exists(src_p):
        print(f"Skipping {d['version']}, source not found: {src_p}")
        continue
    
    target_dir = os.path.join(REPO_ROOT, d["major"], d["folder_name"])
    os.makedirs(target_dir, exist_ok=True)
    
    target_bin = os.path.join(target_dir, d["bin_name"])
    shutil.copy2(src_p, target_bin)
    
    meta_path = os.path.join(target_dir, "metadata.json")
    meta_data = {
        "version": d["version"],
        "major": int(d["major"]),
        "minor": d["minor"],
        "sku": d["sku"],
        "power": d["power"],
        "status": d["status"],
        "origin": d["origin"],
        "original_filename": d["bin_name"]
    }
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta_data, f, indent=4)
        
    print(f"Successfully installed donor: {d['version']} ({d['sku']} {d['power']}) -> {target_dir}")
    installed.append(target_bin)

print(f"\nTotal new donors installed in repository: {len(installed)}")
