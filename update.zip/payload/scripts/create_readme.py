import os

README_PATH = r"C:\Users\R1 LAB\Desktop\MUNNA VI\New folder\REPAIRED_BIOS\README_REPAIR_NOTES.txt"

content = """================================================================================
DELL LATITUDE 5450 / PRECISION 3490 (LA-M366P Rev 1.0) BIOS REPAIR REPORT
================================================================================
Target Board: Dell Latitude 5450 / Precision 3490 (Motherboard: LA-M366P Rev 1.0)
Processor Platform: Intel Raptor Lake / Alder Lake (RPL/ADL-LP)
BIOS Chip Size: 32 MB (33,554,432 bytes)
CSME Version: 16.1.42.2872 (Consumer LP)
PMC Version: 160.1.0.1031 (LP C)
PCHC Version: 16.1.0.1014
PHY Version: 14.531.509.8259

REPAIRED FILE:
- File Name: Latitude_5450_LA-M366P_REPAIRED_FULL_v1.27.1.BIN
- Location:  C:\\Users\\R1 LAB\\Desktop\\MUNNA VI\\New folder\\REPAIRED_BIOS\\
- Source 1 (Base Descriptor & EC): Original Dump (LA-M366P Rev 1.0.BIN)
- Source 2 (BIOS Region 24MB):     Official Dell Release v1.27.1 (System BIOS with BiosGuard)
- CSME Status:                     16.1.42.2872 Clean & Synchronized

FLASHING & BOOTING INSTRUCTIONS:
1. Write 'Latitude_5450_LA-M366P_REPAIRED_FULL_v1.27.1.BIN' to the 32MB SPI flash chip using programmer.
2. Solder chip back and power on the laptop.
3. First boot may power cycle 2 to 3 times for memory retraining and PCH strap initialization.
4. If prompted with "Manufacturing Mode / Service Tag Entry", enter the laptop's original Service Tag from the bottom chassis label.
================================================================================
"""

with open(README_PATH, "w", encoding="utf-8") as f:
    f.write(content)

print("Created README at:", README_PATH)
